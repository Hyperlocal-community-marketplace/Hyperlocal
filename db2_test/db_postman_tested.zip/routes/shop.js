const express = require("express");
const path = require("path");
const router = express.Router();
const fs = require("fs");
const jwt = require("jsonwebtoken");
const sendMail = require("../utils/sendMail");
const { isAuthenticated, isSeller, isAdmin } = require("../middleware/auth");
const { upload } = require("../multer");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const pool = require("../db/db"); // Corrected path

const sendShopToken = require("../utils/shopToken");

// create activation token
const createActivationToken = (seller) => {
  return jwt.sign(seller, process.env.ACTIVATION_SECRET, {
    expiresIn: "5m",
  });
};

// create shop
router.post(
  "/create-shop",
  upload.single("file"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email } = req.body;

      const [existingShop] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);
      if (existingShop.length > 0) {
        // Delete uploaded file if user exists
        const filename = req.file.filename;
        fs.unlink(`uploads/${filename}`, (err) => {
          if (err) console.error(err);
        });

        return next(new ErrorHandler("User already exists", 400));
      }

      const filename = req.file.filename;
      const fileUrl = filename;

      const seller = {
        name: req.body.name,
        email: email,
        password: req.body.password, // Reminder: Hash password before use in real app
        avatar: fileUrl,
        address: req.body.address,
        phoneNumber: req.body.phoneNumber,
        zipCode: req.body.zipCode,
      };

      const activationToken = createActivationToken(seller);
      const activationUrl = `http://localhost:3000/seller/activation/${activationToken}`;

      // Re-enabled sendMail
      await sendMail({
        email: seller.email,
        subject: "Activate your Shop",
        message: `Hello ${seller.name}, please click on the link to activate your shop: ${activationUrl}`,
      });

      res.status(201).json({
        success: true,
        message: `Please check your email:- ${seller.email} to activate your shop!`,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// activate shop
router.post(
  "/activation",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { activation_token } = req.body;

      const newSeller = jwt.verify(activation_token, process.env.ACTIVATION_SECRET);

      if (!newSeller) {
        return next(new ErrorHandler("Invalid token", 400));
      }

      const { name, email, password, avatar, zipCode, address, phoneNumber } = newSeller;

      const [sellerExists] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);

      if (sellerExists.length > 0) {
        return next(new ErrorHandler("User already exists", 400));
      }

      // Reminder: Hash password before inserting in real app
      const [result] = await pool.query(
        "INSERT INTO Shops (name, email, avatar, password, zipCode, address, phoneNumber) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [name, email, avatar, password, zipCode, address, phoneNumber]
      );

      const [seller] = await pool.query("SELECT * FROM Shops WHERE id = ?", [result.insertId]);

      sendShopToken(seller[0], 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// login shop
router.post(
  "/login-shop",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email, password } = req.body;

      if (!email || !password) {
        return next(new ErrorHandler("Please provide all the fields!", 400));
      }

      const [users] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);
      if (users.length === 0) {
        return next(new ErrorHandler("User doesn't exist!", 400));
      }

      const user = users[0];

      // Reminder: Implement password compare with bcrypt in real app
      if (password !== user.password) {
        return next(new ErrorHandler("Please provide the correct information", 400));
      }

      sendShopToken(user, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// load shop
router.get(
  "/getSeller",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) {
        return next(new ErrorHandler("User doesn't exist", 400));
      }
      res.status(200).json({
        success: true,
        seller: shops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// log out from shop
router.get(
  "/logout",
  catchAsyncErrors(async (req, res, next) => {
    try {
      res.cookie("seller_token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
      });
      res.status(201).json({
        success: true,
        message: "Log out successful!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get shop info by id
router.get(
  "/get-shop-info/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.params.id]);
      res.status(201).json({
        success: true,
        shop: shops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update shop avatar
router.put(
  "/update-shop-avatar",
  isSeller,
  upload.single("image"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) {
        return next(new ErrorHandler("Seller not found", 400));
      }

      const shop = shops[0];
      const existAvatarPath = `uploads/${shop.avatar}`;
      if (fs.existsSync(existAvatarPath)) {
        fs.unlinkSync(existAvatarPath);
      }

      const fileUrl = req.file.filename;

      await pool.query("UPDATE Shops SET avatar = ? WHERE id = ?", [fileUrl, req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(200).json({
        success: true,
        seller: updatedShops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update seller info
router.put(
  "/update-seller-info",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { name, description, address, phoneNumber, zipCode } = req.body;

      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) {
        return next(new ErrorHandler("User not found", 400));
      }

      await pool.query(
        "UPDATE Shops SET name = ?, description = ?, address = ?, phoneNumber = ?, zipCode = ? WHERE id = ?",
        [name, description, address, phoneNumber, zipCode, req.seller.id]
      );

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({
        success: true,
        shop: updatedShops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// all sellers --- for admin
router.get(
  "/admin-all-sellers",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [sellers] = await pool.query("SELECT * FROM Shops ORDER BY createdAt DESC");
      res.status(201).json({
        success: true,
        sellers,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete seller --- admin
router.delete(
  "/delete-seller/:id",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [sellers] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.params.id]);
      if (sellers.length === 0) {
        return next(new ErrorHandler("Seller is not available with this id", 400));
      }

      await pool.query("DELETE FROM Shops WHERE id = ?", [req.params.id]);

      res.status(201).json({
        success: true,
        message: "Seller deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update seller withdraw methods --- sellers
router.put(
  "/update-payment-methods",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { withdrawMethod } = req.body;

      await pool.query("UPDATE Shops SET withdrawMethod = ? WHERE id = ?", [withdrawMethod, req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({
        success: true,
        seller: updatedShops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete seller withdraw methods --- only seller
router.delete(
  "/delete-withdraw-method/",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) {
        return next(new ErrorHandler("Seller not found with this id", 400));
      }

      await pool.query("UPDATE Shops SET withdrawMethod = NULL WHERE id = ?", [req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({
        success: true,
        seller: updatedShops[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;

