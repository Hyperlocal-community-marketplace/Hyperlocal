const express = require('express');
const router = express.Router();
const pool = require('../db/db');
const ErrorHandler = require('../utils/ErrorHandler');
const catchAsyncErrors = require('../middleware/catchAsyncErrors');
const { isSeller, isAuthenticated } = require('../middleware/auth');

// Create a new conversation
router.post(
  '/create-new-conversation',
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { groupTitle, userId, sellerId } = req.body;
      const [existing] = await pool.query('SELECT * FROM CONVERSATION WHERE groupTitle = ?', [groupTitle]);
      if (existing.length > 0) {
        return res.status(201).json({
          success: true,
          conversation: existing[0]
        });
      }
      const [result] = await pool.query(
        'INSERT INTO CONVERSATION (groupTitle, userId, sellerId, createdAt, updatedAt) VALUES (?, ?, ?, NOW(), NOW())',
        [groupTitle, userId, sellerId]
      );
      const [newConversation] = await pool.query('SELECT * FROM CONVERSATION WHERE id = ?', [result.insertId]);
      res.status(201).json({
        success: true,
        conversation: newConversation[0]
      });
    } catch (error) {
      return next(new ErrorHandler(error.message), 500);
    }
  })
);


// Get all conversations for seller
router.get(
  '/get-all-conversation-seller/:id',
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [conversations] = await pool.query(
        'SELECT * FROM CONVERSATION WHERE sellerId = ? ORDER BY updatedAt DESC, createdAt DESC',
        [req.params.id]
      );

      res.status(201).json({
        success: true,
        conversations
      });
    } catch (error) {
      return next(new ErrorHandler(error.message), 500);
    }
  })
);

// Get all conversations for user
router.get(
  '/get-all-conversation-user/:id',
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [conversations] = await pool.query(
        'SELECT * FROM CONVERSATION WHERE userId = ? ORDER BY updatedAt DESC, createdAt DESC',
        [req.params.id]
      );

      res.status(201).json({
        success: true,
        conversations
      });
    } catch (error) {
      return next(new ErrorHandler(error.message), 500);
    }
  })
);

// Update last message of conversation
router.put(
  '/update-last-message/:id',
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { lastMessage, lastMessageId } = req.body;

      await pool.query(
        'UPDATE CONVERSATION SET lastMessage = ?, lastMessageId = ?, updatedAt = NOW() WHERE id = ?',
        [lastMessage, lastMessageId, req.params.id]
      );

      // Return updated record
      const [updated] = await pool.query('SELECT * FROM CONVERSATION WHERE id = ?', [req.params.id]);

      res.status(201).json({
        success: true,
        conversation: updated[0]
      });
    } catch (error) {
      return next(new ErrorHandler(error.message), 500);
    }
  })
);

module.exports = router;
