const express = require("express");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const { upload } = require("../multer");
const ErrorHandler = require("../utils/ErrorHandler");
const { isSeller, isAdmin, isAuthenticated } = require("../middleware/auth");
const router = express.Router();
const fs = require("fs");
const pool = require("../db"); // Ensure your MySQL promise pool is imported

// Create event with images
router.post(
  "/create-event",
  upload.array("images"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { shopId, title, description, startDate, endDate } = req.body;

      const [shopCheck] = await pool.query("SELECT * FROM Shops WHERE id = ?", [shopId]);
      if (shopCheck.length === 0) {
        return next(new ErrorHandler("Shop Id is invalid!", 400));
      }

      const [result] = await pool.query(
        "INSERT INTO EVENT (shopId, title, description, startDate, endDate) VALUES (?, ?, ?, ?, ?)",
        [shopId, title, description, startDate, endDate]
      );

      const eventId = result.insertId;

      const files = req.files;
      if (files && files.length > 0) {
        const placeholders = files.map(() => "(?, ?)").join(", ");
        const values = [];
        files.forEach((file) => {
          values.push(eventId, file.filename);
        });

        await pool.query(`INSERT INTO EVENT_IMAGES (eventId, filename) VALUES ${placeholders}`, values);
      }

      const [eventRows] = await pool.query("SELECT * FROM EVENT WHERE id = ?", [eventId]);
      const [imageRows] = await pool.query("SELECT filename FROM EVENT_IMAGES WHERE eventId = ?", [eventId]);

      eventRows[0].images = imageRows.map((img) => img.filename);

      res.status(201).json({
        success: true,
        event: eventRows[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// Get all events with images
router.get(
  "/get-all-events",
  catchAsyncErrors(async (req, res, next) => {
    const [events] = await pool.query("SELECT * FROM EVENT");

    for (let event of events) {
      const [images] = await pool.query("SELECT filename FROM EVENT_IMAGES WHERE eventId = ?", [event.id]);
      event.images = images.map((img) => img.filename);
    }

    res.status(200).json({
      success: true,
      events,
    });
  })
);

// Get all events for a shop
router.get(
  "/get-all-events/:id",
  catchAsyncErrors(async (req, res, next) => {
    const shopId = req.params.id;

    const [events] = await pool.query("SELECT * FROM EVENT WHERE shopId = ?", [shopId]);

    for (let event of events) {
      const [images] = await pool.query("SELECT filename FROM EVENT_IMAGES WHERE eventId = ?", [event.id]);
      event.images = images.map((img) => img.filename);
    }

    res.status(200).json({
      success: true,
      events,
    });
  })
);

// Delete event and associated images
router.delete(
  "/delete-shop-event/:id",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    const eventId = req.params.id;

    const [eventRows] = await pool.query("SELECT * FROM EVENT WHERE id = ?", [eventId]);

    if (eventRows.length === 0) {
      return next(new ErrorHandler("Event not found with this id!", 404));
    }

    // Delete files from disk
    const [images] = await pool.query("SELECT filename FROM EVENT_IMAGES WHERE eventId = ?", [eventId]);
    images.forEach(({ filename }) => {
      const filePath = `uploads/${filename}`;
      fs.unlink(filePath, (err) => {
        if (err) {
          console.error("Failed to delete file:", filePath, err);
        }
      });
    });

    // Delete event (will cascade delete images and reviews via FK ON DELETE CASCADE)
    await pool.query("DELETE FROM EVENT WHERE id = ?", [eventId]);

    res.status(200).json({
      success: true,
      message: "Event deleted successfully!",
    });
  })
);

// Create or update review for an event
router.put(
  "/create-new-review-event",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    const { userId, rating, comment, eventId } = req.body;

    const [existingReviews] = await pool.query(
      "SELECT * FROM EVENT_REVIEWS WHERE eventId = ? AND userId = ?",
      [eventId, userId]
    );

    if (existingReviews.length > 0) {
      await pool.query(
        "UPDATE EVENT_REVIEWS SET rating = ?, comment = ? WHERE id = ?",
        [rating, comment, existingReviews[0].id]
      );
    } else {
      await pool.query(
        "INSERT INTO EVENT_REVIEWS (eventId, userId, rating, comment) VALUES (?, ?, ?, ?)",
        [eventId, userId, rating, comment]
      );
    }

    // Recalculate average rating
    const [ratings] = await pool.query(
      "SELECT AVG(rating) AS avgRating FROM EVENT_REVIEWS WHERE eventId = ?",
      [eventId]
    );
    const avgRating = ratings[0].avgRating;

    await pool.query("UPDATE EVENT SET ratings = ? WHERE id = ?", [avgRating, eventId]);

    res.status(200).json({
      success: true,
      message: "Reviewed successfully!",
    });
  })
);

module.exports = router;
