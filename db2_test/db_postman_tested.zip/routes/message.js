const express = require('express');
const catchAsyncErrors = require('../middleware/catchAsyncErrors');
const ErrorHandler = require('../utils/ErrorHandler');
const { upload } = require('../multer');
const path = require('path');
const pool = require('../db'); // Your mysql2 promise pool
const router = express.Router();

// Create new message
router.post(
  '/create-new-message',
  upload.single('images'),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { conversationId, sender, text } = req.body;
      let images = null;

      if (req.file) {
        images = req.file.filename;
      }

      const [result] = await pool.query(
        'INSERT INTO MESSAGES (conversationId, sender, text, images) VALUES (?, ?, ?, ?)',
        [conversationId, sender, text, images]
      );

      // Fetch the inserted message
      const [messages] = await pool.query('SELECT * FROM MESSAGES WHERE id = ?', [result.insertId]);

      res.status(201).json({
        success: true,
        message: messages[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Get all messages in a conversation
router.get(
  '/get-all-messages/:id',
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [messages] = await pool.query('SELECT * FROM MESSAGES WHERE conversationId = ?', [req.params.id]);

      res.status(200).json({
        success: true,
        messages,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
