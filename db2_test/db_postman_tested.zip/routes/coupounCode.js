const express = require('express');
const catchAsyncErrors = require('../middleware/catchAsyncErrors');
const ErrorHandler = require('../utils/ErrorHandler');
const { isSeller } = require('../middleware/auth');
const pool = require('../db');
const router = express.Router();

// create coupon code
router.post(
  '/create-coupon-code',
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    const { name, value, shopId } = req.body;

    // check if coupon code already exists for this shop
    const [existing] = await pool.query('SELECT * FROM COUPONCODE WHERE name = ? AND shopId = ?', [name, shopId]);
    if (existing.length !== 0) {
      return next(new ErrorHandler('Coupon code already exists!', 400));
    }

    // insert the new coupon code
    const [result] = await pool.query(
      'INSERT INTO COUPONCODE (name, value, shopId, createdAt) VALUES (?, ?, ?, NOW())',
      [name, value, shopId]
    );

    // fetch the newly inserted coupon code
    const [newCoupon] = await pool.query('SELECT * FROM COUPONCODE WHERE id = ?', [result.insertId]);

    res.status(201).json({
      success: true,
      coupounCode: newCoupon[0],
    });
  })
);

// get all coupons of a shop
router.get(
  '/get-coupon/:id',
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    // shopId comes from the authenticated seller
    const shopId = req.seller.id;

    const [couponCodes] = await pool.query('SELECT * FROM COUPONCODE WHERE shopId = ?', [shopId]);

    res.status(201).json({
      success: true,
      couponCodes,
    });
  })
);

// delete coupon code of a shop
router.delete(
  '/delete-coupon/:id',
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    const couponId = req.params.id;

    // check if coupon exists
    const [coupon] = await pool.query('SELECT * FROM COUPONCODE WHERE id = ?', [couponId]);
    if (coupon.length === 0) {
      return next(new ErrorHandler("Coupon code doesn't exist!", 400));
    }

    // delete coupon code
    await pool.query('DELETE FROM COUPONCODE WHERE id = ?', [couponId]);

    res.status(201).json({
      success: true,
      message: 'Coupon code deleted successfully!',
    });
  })
);

// get coupon code value by its name
router.get(
  '/get-coupon-value/:name',
  catchAsyncErrors(async (req, res, next) => {
    const { name } = req.params;

    const [couponCode] = await pool.query('SELECT * FROM COUPONCODE WHERE name = ?', [name]);

    res.status(200).json({
      success: true,
      couponCode: couponCode[0] || null,
    });
  })
);

module.exports = router;
