const express = require("express");
const router = express.Router();
const path = require("path");
const fs = require("fs");
const jwt = require("jsonwebtoken");
const sendMail = require("../utils/sendMail");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const pool = require("../db");
const { upload } = require("../multer");
const sendShopToken = require("../utils/shopToken");
const { isAuthenticated, isSeller, isAdmin } = require("../middleware/auth");

// create activation token
const createActivationToken = (seller) =>
  jwt.sign(seller, process.env.ACTIVATION_SECRET, { expiresIn: "5m" });

// create shop
router.post(
  "/create-shop",
  upload.single("file"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email, name, password, address, phoneNumber, zipCode } = req.body;

      const [existingShops] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);
      if (existingShops.length > 0) {
        if (req.file) {
          const filename = req.file.filename;
          fs.unlink(`uploads/${filename}`, (err) => {
            if (err) console.error(err);
          });
        }
        return next(new ErrorHandler("User already exists", 400));
      }

      const filename = req.file.filename;
      const fileUrl = filename;

      const seller = { name, email, password, avatar: fileUrl, address, phoneNumber, zipCode };

      const activationToken = createActivationToken(seller);
      const activationUrl = `http://localhost:3000/seller/activation/${activationToken}`;

      await sendMail({
        email: seller.email,
        subject: "Activate your Shop",
        message: `Hello ${seller.name}, please click on the link to activate your shop: ${activationUrl}`,
      });

      res.status(201).json({
        success: true,
        message: `Please check your email:- ${seller.email} to activate your shop!`,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// activate shop
router.post(
  "/activation",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { activation_token } = req.body;
      const newSeller = jwt.verify(activation_token, process.env.ACTIVATION_SECRET);
      if (!newSeller) return next(new ErrorHandler("Invalid token", 400));

      const { name, email, password, avatar, zipCode, address, phoneNumber } = newSeller;

      const [sellers] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);
      if (sellers.length > 0) return next(new ErrorHandler("User already exists", 400));

      const [result] = await pool.query(
        "INSERT INTO Shops (name, email, password, avatar, zipCode, address, phoneNumber) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [name, email, password, avatar, zipCode, address, phoneNumber]
      );

      const [seller] = await pool.query("SELECT * FROM Shops WHERE id = ?", [result.insertId]);

      sendShopToken(seller[0], 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// login shop
router.post(
  "/login-shop",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) return next(new ErrorHandler("Please provide all fields", 400));

      const [shops] = await pool.query("SELECT * FROM Shops WHERE email = ?", [email]);
      if (shops.length === 0) return next(new ErrorHandler("User doesn't exist", 400));

      const shop = shops[0];
      if (password !== shop.password) return next(new ErrorHandler("Incorrect password", 400));

      sendShopToken(shop, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// load shop
router.get(
  "/getSeller",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) return next(new ErrorHandler("User doesn't exist", 400));

      res.status(200).json({ success: true, seller: shops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// logout shop
router.get(
  "/logout",
  catchAsyncErrors(async (req, res, next) => {
    try {
      res.cookie("seller_token", null, { expires: new Date(Date.now()), httpOnly: true });
      res.status(201).json({ success: true, message: "Log out successful!" });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// get shop info by id
router.get(
  "/get-shop-info/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.params.id]);
      res.status(201).json({ success: true, shop: shops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update shop avatar
router.put(
  "/update-shop-avatar",
  isSeller,
  upload.single("image"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) return next(new ErrorHandler("Seller not found", 400));

      const shop = shops[0];
      const avatarPath = `uploads/${shop.avatar}`;
      if (fs.existsSync(avatarPath)) fs.unlinkSync(avatarPath);

      const fileUrl = req.file.filename;

      await pool.query("UPDATE Shops SET avatar = ? WHERE id = ?", [fileUrl, req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(200).json({ success: true, seller: updatedShops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update seller info
router.put(
  "/update-seller-info",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { name, description, address, phoneNumber, zipCode } = req.body;

      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) return next(new ErrorHandler("User not found", 400));

      await pool.query(
        "UPDATE Shops SET name = ?, description = ?, address = ?, phoneNumber = ?, zipCode = ? WHERE id = ?",
        [name, description, address, phoneNumber, zipCode, req.seller.id]
      );

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({ success: true, shop: updatedShops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// all sellers for admin
router.get(
  "/admin-all-sellers",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [sellers] = await pool.query("SELECT * FROM Shops ORDER BY createdAt DESC");
      res.status(201).json({ success: true, sellers });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete seller admin
router.delete(
  "/delete-seller/:id",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.params.id]);
      if (shops.length === 0) return next(new ErrorHandler("Seller not found with this id", 400));

      await pool.query("DELETE FROM Shops WHERE id = ?", [req.params.id]);

      res.status(201).json({ success: true, message: "Seller deleted successfully!" });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update seller withdraw methods
router.put(
  "/update-payment-methods",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { withdrawMethod } = req.body;

      await pool.query("UPDATE Shops SET withdrawMethod = ? WHERE id = ?", [withdrawMethod, req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({ success: true, seller: updatedShops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete seller withdraw methods
router.delete(
  "/delete-withdraw-method",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [shops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);
      if (shops.length === 0) return next(new ErrorHandler("Seller not found with this id", 400));

      await pool.query("UPDATE Shops SET withdrawMethod = NULL WHERE id = ?", [req.seller.id]);

      const [updatedShops] = await pool.query("SELECT * FROM Shops WHERE id = ?", [req.seller.id]);

      res.status(201).json({ success: true, seller: updatedShops[0] });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;
