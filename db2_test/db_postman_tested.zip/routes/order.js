const express = require("express");
const router = express.Router();
const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const { isAuthenticated, isSeller, isAdmin } = require("../middleware/auth");
const pool = require("../db/db"); // Correct path

// Create new order (This route is correct)
router.post(
  "/create-order",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { cart, shippingAddress, user, totalPrice, paymentInfo } = req.body;

      // Group cart items by shopId
      const shopItemsMap = new Map();
      for (const item of cart) {
        const shopId = item.shopId;
        if (!shopItemsMap.has(shopId)) shopItemsMap.set(shopId, []);
        shopItemsMap.get(shopId).push(item);
      }

      // Insert an order per shop
      const insertedOrders = [];
      for (const [shopId, items] of shopItemsMap) {
        const [result] = await pool.query(
          `INSERT INTO ORDERS (cart, shippingAddress, user, totalPrice, paymentInfo, shopId, status, createdAt, updatedAt) VALUES (?, ?, ?, ?, ?, ?, 'Pending', NOW(), NOW())`,
          [
            JSON.stringify(items),
            JSON.stringify(shippingAddress),
            JSON.stringify(user),
            totalPrice,
            JSON.stringify(paymentInfo),
            shopId,
          ]
        );

        const [insertedOrder] = await pool.query(
          "SELECT * FROM ORDERS WHERE id = ?",
          [result.insertId]
        );
        insertedOrders.push(insertedOrder[0]);
      }

      res.status(201).json({
        success: true,
        orders: insertedOrders,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Get all orders of a user (Correct)
router.get(
  "/get-all-orders/:userId",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const userId = req.params.userId;
      const [orders] = await pool.query(
        'SELECT * FROM ORDERS WHERE JSON_EXTRACT(user, "$.id") = ? ORDER BY createdAt DESC',
        [userId]
      );
      res.status(200).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Get all orders of a seller (Correct)
router.get(
  "/get-seller-all-orders/:shopId",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const shopId = req.params.shopId;
      const [orders] = await pool.query(
        "SELECT * FROM ORDERS WHERE shopId = ? ORDER BY createdAt DESC",
        [shopId]
      );

      res.status(200).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Update order status for seller (--- THIS IS THE UPDATED SECTION ---)
router.put(
  "/update-order-status/:id",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const orderId = req.params.id;
      const { status } = req.body;

      const [orderRows] = await pool.query("SELECT * FROM ORDERS WHERE id = ?", [
        orderId,
      ]);
      if (orderRows.length === 0) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }
      const order = orderRows[0];

      if (status === "Transferred to delivery partner") {
        // --- THIS IS FIX #1 ---
        // Check if cart is a string before parsing
        const cart =
          typeof order.cart === "string"
            ? JSON.parse(order.cart)
            : order.cart;

        for (const o of cart) {
          const productId = o.id || o._id;
          await updateProductStock(productId, o.qty, false /* decrease stock */);
        }
      }

      let deliveredAt = order.deliveredAt;

      // --- THIS IS FIX #2 ---
      // Check if paymentInfo is a string before parsing
      let paymentInfo =
        typeof order.paymentInfo === "string"
          ? JSON.parse(order.paymentInfo)
          : order.paymentInfo;

      if (status === "Delivered") {
        deliveredAt = new Date();
        paymentInfo.status = "Succeeded";
        const serviceCharge = order.totalPrice * 0.1;
        await updateSellerBalance(
          order.shopId,
          order.totalPrice - serviceCharge
        );
      }

      await pool.query(
        "UPDATE ORDERS SET status = ?, deliveredAt = ?, paymentInfo = ?, updatedAt = NOW() WHERE id = ?",
        [status, deliveredAt, JSON.stringify(paymentInfo), orderId] // Stringify here is correct
      );

      const [updatedOrderRows] = await pool.query(
        "SELECT * FROM ORDERS WHERE id = ?",
        [orderId]
      );

      res.status(200).json({
        success: true,
        order: updatedOrderRows[0],
      });

      // (This helper function is correct, uses "Products")
      async function updateProductStock(productId, qty, increaseStock = true) {
        const [productRows] = await pool.query(
          "SELECT * FROM Products WHERE id = ?",
          [productId]
        );
        if (productRows.length === 0) throw new Error("Product not found");

        let stock = productRows[0].stock;
        let sold_out = productRows[0].sold_out;

        if (increaseStock) {
          stock += qty;
          sold_out -= qty;
        } else {
          stock -= qty;
          sold_out += qty;
        }

        await pool.query(
          "UPDATE Products SET stock = ?, sold_out = ? WHERE id = ?",
          [stock, sold_out, productId]
        );
      }

      // (This helper function is correct)
      async function updateSellerBalance(shopId, amount) {
        const [sellerRows] = await pool.query(
          "SELECT * FROM Shops WHERE id = ?",
          [shopId]
        );
        if (sellerRows.length === 0) throw new Error("Seller not found");

        const newBalance = parseFloat(sellerRows[0].availableBalance) + amount;
        await pool.query("UPDATE Shops SET availableBalance = ? WHERE id = ?", [
          newBalance,
          shopId,
        ]);
      }
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// All other routes (refunds, admin) remain the same...
// ...
// User requests refund on order
router.put(
  "/order-refund/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const orderId = req.params.id;
      const { status } = req.body;

      const [orderRows] = await pool.query("SELECT * FROM ORDERS WHERE id = ?", [
        orderId,
      ]);
      if (orderRows.length === 0) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }

      await pool.query(
        "UPDATE ORDERS SET status = ?, updatedAt = NOW() WHERE id = ?",
        [status, orderId]
      );

      const [updatedOrderRows] = await pool.query(
        "SELECT * FROM ORDERS WHERE id = ?",
        [orderId]
      );

      res.status(200).json({
        success: true,
        order: updatedOrderRows[0],
        message: "Order Refund Request successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Seller accepts refund request
router.put(
  "/order-refund-success/:id",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const orderId = req.params.id;
      const { status } = req.body;

      const [orderRows] = await pool.query("SELECT * FROM ORDERS WHERE id = ?", [
        orderId,
      ]);
      if (orderRows.length === 0) {
        return next(new ErrorHandler("Order not found with this id", 400));
      }
      const order = orderRows[0];

      await pool.query(
        "UPDATE ORDERS SET status = ?, updatedAt = NOW() WHERE id = ?",
        [status, orderId]
      );

      if (status === "Refund Success") {
        const cart =
          typeof order.cart === "string"
            ? JSON.parse(order.cart)
            : order.cart;
            
        for (const o of cart) {
          const productId = o.id || o._id;
          await updateProductStock(productId, o.qty, true /* increase stock */);
        }
      }

      res.status(200).json({
        success: true,
        message: "Order Refund successful!",
      });

      async function updateProductStock(productId, qty, increaseStock = true) {
        const [productRows] = await pool.query(
          "SELECT * FROM Products WHERE id = ?", // Corrected
          [productId]
        );
        if (productRows.length === 0) throw new Error("Product not found");

        let stock = productRows[0].stock;
        let sold_out = productRows[0].sold_out;

        if (increaseStock) {
          stock += qty;
          sold_out -= qty;
        } else {
          stock -= qty;
          sold_out += qty;
        }

        await pool.query(
          "UPDATE Products SET stock = ?, sold_out = ? WHERE id = ?", // Corrected
          [stock, sold_out, productId]
        );
      }
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// Admin gets all orders
router.get(
  "/admin-all-orders",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [orders] = await pool.query(
        "SELECT * FROM ORDERS ORDER BY deliveredAt DESC, createdAt DESC"
      );
      res.status(200).json({
        success: true,
        orders,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);


module.exports = router;

