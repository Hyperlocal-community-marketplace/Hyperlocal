const express = require("express");
const path = require("path");
const router = express.Router();
const fs = require("fs");
const jwt = require("jsonwebtoken");
const sendMail = require("../utils/sendMail");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const ErrorHandler = require("../utils/ErrorHandler");
const pool = require("../db/db"); // Corrected path
const { upload } = require("../multer");
const sendToken = require("../utils/jwtToken");
const { isAuthenticated, isAdmin } = require("../middleware/auth");

// create activation token
const createActivationToken = (user) => {
  return jwt.sign(user, process.env.ACTIVATION_SECRET, {
    expiresIn: "5m",
  });
};

// create user
router.post(
  "/create-user",
  upload.single("file"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { name, email, password } = req.body;

      const [userEmail] = await pool.query("SELECT * FROM Users WHERE email = ?", [email]);
      if (userEmail.length > 0) {
        const filename = req.file.filename;
        fs.unlink(`uploads/${filename}`, (err) => {
          if (err) console.error(err);
        });
        return next(new ErrorHandler("User already exists", 400));
      }

      const filename = req.file.filename;
      const fileUrl = filename;

      const userObj = {
        name,
        email,
        password, // Reminder: hash this password!
        avatar: fileUrl,
      };

      const activationToken = createActivationToken(userObj);
      const activationUrl = `http://localhost:3000/activation/${activationToken}`;

      // Re-enabled sendMail
      await sendMail({
        email: userObj.email,
        subject: "Activate your account",
        message: `Hello ${userObj.name}, please click on the link to activate your account: ${activationUrl}`,
      });

      res.status(201).json({
        success: true,
        message: `Please check your email:- ${userObj.email} to activate your account!`,
      });
    } catch (err) {
      return next(new ErrorHandler(err.message, 400));
    }
  })
);

// activate user
router.post(
  "/activation",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { activation_token } = req.body;
      const newUser = jwt.verify(activation_token, process.env.ACTIVATION_SECRET);
      if (!newUser) return next(new ErrorHandler("Invalid token", 400));

      const { name, email, password, avatar } = newUser;

      const [exists] = await pool.query("SELECT * FROM Users WHERE email = ?", [email]);
      if (exists.length > 0) return next(new ErrorHandler("User already exists", 400));

      // Reminder: Store password hashed in real app
      const [result] = await pool.query(
        "INSERT INTO Users (name, email, password, avatar, createdAt) VALUES (?, ?, ?, ?, NOW())",
        [name, email, password, avatar]
      );

      const [user] = await pool.query("SELECT * FROM Users WHERE id = ?", [result.insertId]);

      sendToken(user[0], 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// login user
router.post(
  "/login-user",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email, password } = req.body;
      if (!email || !password) return next(new ErrorHandler("Please provide all fields", 400));

      const [users] = await pool.query("SELECT * FROM Users WHERE email = ?", [email]);
      if (users.length === 0) return next(new ErrorHandler("User doesn't exist", 400));

      const user = users[0];

      // Reminder: compare password in real app with bcrypt
      if (password !== user.password) return next(new ErrorHandler("Incorrect password", 400));

      sendToken(user, 201, res);
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// load user data
router.get(
  "/getuser",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [req.user.id]);
      if (users.length === 0) return next(new ErrorHandler("User doesn't exist", 400));

      res.status(200).json({
        success: true,
        user: users[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// log out user
router.get(
  "/logout",
  catchAsyncErrors(async (req, res, next) => {
    try {
      res.cookie("token", null, {
        expires: new Date(Date.now()),
        httpOnly: true,
      });

      res.status(201).json({
        success: true,
        message: "Log out successful!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user info
router.put(
  "/update-user-info",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { email, password, phoneNumber, name } = req.body;

      const [users] = await pool.query("SELECT * FROM Users WHERE email = ?", [email]);
      if (users.length === 0) return next(new ErrorHandler("User not found", 400));
      const user = users[0];

      // Reminder: Compare password properly in real app
      if (password !== user.password) return next(new ErrorHandler("Incorrect password", 400));

      await pool.query(
        "UPDATE Users SET name = ?, email = ?, phoneNumber = ? WHERE id = ?",
        [name, email, phoneNumber, user.id]
      );

      const [updatedUsers] = await pool.query("SELECT * FROM Users WHERE id = ?", [user.id]);

      res.status(201).json({
        success: true,
        user: updatedUsers[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user avatar
router.put(
  "/update-avatar",
  isAuthenticated,
  upload.single("image"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [req.user.id]);
      if (users.length === 0) return next(new ErrorHandler("User not found", 400));

      const user = users[0];
      const existAvatarPath = `uploads/${user.avatar}`;
      if (fs.existsSync(existAvatarPath)) {
        fs.unlinkSync(existAvatarPath);
      }

      const fileUrl = req.file.filename;
      await pool.query("UPDATE Users SET avatar = ? WHERE id = ?", [fileUrl, req.user.id]);

      const [updatedUsers] = await pool.query("SELECT * FROM Users WHERE id = ?", [req.user.id]);

      res.status(200).json({
        success: true,
        user: updatedUsers[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user addresses
router.put(
  "/update-user-addresses",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const userId = req.user.id;
      const address = req.body; // should include addressType and other fields

      // Check if address with same type exists
      const [existingAddresses] = await pool.query(
        "SELECT * FROM UserAddresses WHERE userId = ? AND addressType = ?",
        [userId, address.addressType]
      );
      if (existingAddresses.length > 0) {
        return next(new ErrorHandler(`${address.addressType} address already exists`, 400));
      }

      // Insert new address
      await pool.query(
        "INSERT INTO UserAddresses (userId, country, city, address1, address2, zipCode, addressType) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          userId,
          address.country,
          address.city,
          address.address1,
          address.address2,
          address.zipCode,
          address.addressType,
        ]
      );

      const [userAddresses] = await pool.query("SELECT * FROM UserAddresses WHERE userId = ?", [userId]);

      res.status(200).json({
        success: true,
        addresses: userAddresses,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete user address
router.delete(
  "/delete-user-address/:id",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const userId = req.user.id;
      const addressId = req.params.id;

      await pool.query("DELETE FROM UserAddresses WHERE id = ? AND userId = ?", [addressId, userId]);

      const [userAddresses] = await pool.query("SELECT * FROM UserAddresses WHERE userId = ?", [userId]);

      res.status(200).json({ success: true, addresses: userAddresses });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// update user password
router.put(
  "/update-user-password",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const userId = req.user.id;
      const { oldPassword, newPassword, confirmPassword } = req.body;

      const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [userId]);
      if (users.length === 0) return next(new ErrorHandler("User not found", 400));
      const user = users[0];

      if (oldPassword !== user.password) return next(new ErrorHandler("Old password is incorrect!", 400));

      if (newPassword !== confirmPassword) return next(new ErrorHandler("Passwords don't match!", 400));

      // Reminder: In real app, hash password before saving
      await pool.query("UPDATE Users SET password = ? WHERE id = ?", [newPassword, userId]);

      res.status(200).json({
        success: true,
        message: "Password updated successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// find user info by id
router.get(
  "/user-info/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [req.params.id]);
      if (users.length === 0) return next(new ErrorHandler("User not found", 400));

      res.status(201).json({
        success: true,
        user: users[0],
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// all users --- for admin
router.get(
  "/admin-all-users",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [users] = await pool.query("SELECT * FROM Users ORDER BY createdAt DESC");
      res.status(201).json({
        success: true,
        users,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

// delete user --- admin
router.delete(
  "/delete-user/:id",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [req.params.id]);
      if (users.length === 0) return next(new ErrorHandler("User not available with this id", 400));

      await pool.query("DELETE FROM Users WHERE id = ?", [req.params.id]);

      res.status(201).json({
        success: true,
        message: "User deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;

