const express = require("express");
const { isSeller, isAuthenticated, isAdmin } = require("../middleware/auth");
const catchAsyncErrors = require("../middleware/catchAsyncErrors");
const router = express.Router();
const pool = require("../db/db"); // Corrected path
const { upload } = require("../multer");
const ErrorHandler = require("../utils/ErrorHandler");
const fs = require("fs");

// Create product
router.post(
  "/create-product",
  isSeller, // Added authentication
  upload.array("images"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const shopId = req.body.shopId;
      const sellerIdFromToken = req.seller.id;

      // Security Check: Ensure the logged-in seller owns the shop
      if (parseInt(shopId, 10) !== sellerIdFromToken) {
        return next(new ErrorHandler("You are not authorized to add products to this shop", 403));
      }

      const [shop] = await pool.query("SELECT * FROM Shops WHERE id = ?", [shopId]);
      if (shop.length === 0) {
        return next(new ErrorHandler("Shop Id is invalid!", 400));
      }

      const files = req.files;
      if (!files || files.length === 0) {
        return next(new ErrorHandler("You must upload at least one image.", 400));
      }
      
      const imageUrls = files.map((file) => file.filename);

      const productData = {
        shopId: shopId,
        name: req.body.name,
        description: req.body.description,
        category: req.body.category,
        tags: req.body.tags,
        originalPrice: req.body.originalPrice,
        discountPrice: req.body.discountPrice,
        stock: req.body.stock,
      };

      // Insert into Products table
      const [result] = await pool.query(
        `INSERT INTO Products (name, description, category, tags, originalPrice, discountPrice, stock, shopId, createdAt) 
         VALUES (?, ?, ?, ?, ?, ?, ?, ?, NOW())`,
        [
          productData.name,
          productData.description,
          productData.category,
          productData.tags,
          productData.originalPrice,
          productData.discountPrice,
          productData.stock,
          productData.shopId,
        ]
      );

      const productId = result.insertId;

      // Insert images into ProductImages table
      const imageInsertPromises = imageUrls.map(url => {
        return pool.query(
          `INSERT INTO ProductImages (productId, imageUrl) VALUES (?, ?)`,
          [productId, url]
        );
      });
      await Promise.all(imageInsertPromises);

      // Get the final created product
      const [insertedProduct] = await pool.query("SELECT * FROM Products WHERE id = ?", [productId]);

      res.status(201).json({
        success: true,
        product: insertedProduct[0],
      });
    } catch (error) {
      // If error, delete uploaded files to prevent orphans
      if (req.files) {
        req.files.forEach((file) => {
          fs.unlink(file.path, (err) => {
            if (err) console.error("Error deleting file after failed product creation:", err);
          });
        });
      }
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// Get all products of a shop
router.get(
  "/get-all-products-shop/:id",
  catchAsyncErrors(async (req, res, next) => {
    try {
      const shopId = req.params.id;
      
      // Join Products with ProductImages
      const [products] = await pool.query(
        `SELECT p.*, JSON_ARRAYAGG(pi.imageUrl) as images 
         FROM Products p 
         LEFT JOIN ProductImages pi ON p.id = pi.productId 
         WHERE p.shopId = ? 
         GROUP BY p.id`, 
        [shopId]
      );
      
      // Clean up the images array for products with no images
      products.forEach(p => {
        if (p.images && p.images[0] === null) {
          p.images = [];
        }
      });

      res.status(200).json({
        success: true,
        products,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// Delete product of a shop
router.delete(
  "/delete-shop-product/:id",
  isSeller,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const productId = req.params.id;
      const sellerId = req.seller.id;

      // Find the product and verify ownership
      const [productRows] = await pool.query("SELECT * FROM Products WHERE id = ?", [productId]);
      if (productRows.length === 0) {
        return next(new ErrorHandler("Product not found with this id!", 404));
      }
      
      const product = productRows[0];
      if (product.shopId !== sellerId) {
        return next(new ErrorHandler("You are not authorized to delete this product", 403));
      }

      // Find image filenames from ProductImages
      const [images] = await pool.query("SELECT * FROM ProductImages WHERE productId = ?", [productId]);

      // Delete images from 'uploads' folder
      if (images.length > 0) {
        images.forEach((image) => {
          const filePath = `uploads/${image.imageUrl}`;
          if (fs.existsSync(filePath)) { // Check if file exists before unlinking
            fs.unlink(filePath, (err) => {
              if (err) {
                console.log(err);
              }
            });
          }
        });
      }
      
      // Delete from ProductImages (child table) first
      await pool.query("DELETE FROM ProductImages WHERE productId = ?", [productId]);

      // Delete from Products (parent table)
      await pool.query("DELETE FROM Products WHERE id = ?", [productId]);

      res.status(200).json({
        success: true,
        message: "Product Deleted successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// Get all products
router.get(
  "/get-all-products",
  catchAsyncErrors(async (req, res, next) => {
    try {
      // Join Products with ProductImages
      const [products] = await pool.query(
        `SELECT p.*, JSON_ARRAYAGG(pi.imageUrl) as images 
         FROM Products p 
         LEFT JOIN ProductImages pi ON p.id = pi.productId 
         GROUP BY p.id 
         ORDER BY p.createdAt DESC`
      );

      // Clean up the images array for products with no images
      products.forEach(p => {
        if (p.images && p.images[0] === null) {
          p.images = [];
        }
      });

      res.status(200).json({
        success: true,
        products,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// Review for a product
router.put(
  "/create-new-review",
  isAuthenticated,
  catchAsyncErrors(async (req, res, next) => {
    try {
      const { userId, userName, rating, comment, productId, orderId } = req.body;
      const user = req.user; // Get user from auth middleware

      // Check if review exists
      const [existingReviews] = await pool.query(
        "SELECT * FROM ProductReviews WHERE productId = ? AND userId = ?",
        [productId, user.id]
      );

      if (existingReviews.length > 0) {
        // Update existing review
        await pool.query(
          "UPDATE ProductReviews SET rating = ?, comment = ? WHERE id = ?",
          [rating, comment, existingReviews[0].id]
        );
      } else {
        // Insert new review
        await pool.query(
          "INSERT INTO ProductReviews (productId, userId, rating, comment, createdAt) VALUES (?, ?, ?, ?, NOW())",
          [productId, user.id, rating, comment]
        );
      }

      // Recalculate average ratings
      const [ratings] = await pool.query(
        "SELECT AVG(rating) AS avgRating FROM ProductReviews WHERE productId = ?",
        [productId]
      );
      const avgRating = ratings[0].avgRating || 0;

      await pool.query("UPDATE Products SET ratings = ? WHERE id = ?", [avgRating, productId]);

      // This part of your original schema (updating order) is complex,
      // as it relies on finding the item in the JSON array.
      // This query is complex and untested.
      /*
      await pool.query(
        "UPDATE ORDERS SET cart = JSON_SET(cart, REPLACE(JSON_SEARCH(cart, 'one', ?, NULL, '$[*].id'), '.id', '.isReviewed'), true) WHERE id = ?",
        [productId, orderId]
      );
      */

      res.status(200).json({
        success: true,
        message: "Reviewed successfully!",
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 400));
    }
  })
);

// All products --- for admin
router.get(
  "/admin-all-products",
  isAuthenticated,
  isAdmin("Admin"),
  catchAsyncErrors(async (req, res, next) => {
    try {
      const [products] = await pool.query(
        `SELECT p.*, JSON_ARRAYAGG(pi.imageUrl) as images 
         FROM Products p 
         LEFT JOIN ProductImages pi ON p.id = pi.productId 
         GROUP BY p.id 
         ORDER BY p.createdAt DESC`
      );
      
      products.forEach(p => {
        if (p.images && p.images[0] === null) {
          p.images = [];
        }
      });

      res.status(200).json({
        success: true,
        products,
      });
    } catch (error) {
      return next(new ErrorHandler(error.message, 500));
    }
  })
);

module.exports = router;

