const mysql = require('mysql2/promise');

const pool = mysql.createPool({
  host: '127.0.0.1',    // your host IP
  user: 'root',         // your MySQL username
  password: 'keerti',   // your MySQL password
  database: 'testdb',   // database name
  waitForConnections: true,
  connectionLimit: 10
});

module.exports = pool;
