const ErrorHandler = require("../utils/ErrorHandler");
const catchAsyncErrors = require("./catchAsyncErrors");
const jwt = require("jsonwebtoken");
const pool = require("../db/db"); // Corrected path

// Check if user is authenticated or not
exports.isAuthenticated = catchAsyncErrors(async (req, res, next) => {
  const { token } = req.cookies;
  if (!token) {
    return next(new ErrorHandler("Please login to continue", 401));
  }

  const decoded = jwt.verify(token, process.env.JWT_SECRET_KEY);

  const [users] = await pool.query("SELECT * FROM Users WHERE id = ?", [decoded.id]);
  if (users.length === 0) {
    return next(new ErrorHandler("User not found", 401));
  }
  req.user = users[0];
  next();
});

// Check if seller is authenticated
exports.isSeller = catchAsyncErrors(async (req, res, next) => {
  const { seller_token } = req.cookies;
  if (!seller_token) {
    return next(new ErrorHandler("Please login to continue", 401));
  }

  const decoded = jwt.verify(seller_token, process.env.JWT_SECRET_KEY);

  const [sellers] = await pool.query("SELECT * FROM Shops WHERE id = ?", [decoded.id]);
  if (sellers.length === 0) {
    return next(new ErrorHandler("Seller not found", 401));
  }
  req.seller = sellers[0];
  next();
});

// Role based authorization check
exports.isAdmin = (...roles) => {
  return (req, res, next) => {
    if (!roles.includes(req.user.role)) {
      return next(new ErrorHandler(`${req.user.role} cannot access this resource!`));
    }
    next();
  };
};

