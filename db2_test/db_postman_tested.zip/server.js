require('dotenv').config({ path: './config/.env' });

const express = require('express');
const db = require('./db/db');
const conversationRoutes = require('./routes/conversation');
const userRoutes = require('./routes/user');
const shopRoutes = require('./routes/shop');
const productRoutes = require('./routes/product');
const orderRoutes = require('./routes/order'); // <-- This line was missing

const app = express();

const cookieParser = require('cookie-parser');
app.use(cookieParser());

app.use(express.json()); // to parse JSON bodies

// Simple test route for current time
app.get('/', (req, res) => {
  db.query('SELECT NOW() AS currentTime', (err, results) => {
    if (err) throw err;
    res.send(results[0]);
  });
});

// Mount conversation routes
app.use('/api/conversation', conversationRoutes);

// Mount user routes
app.use('/api/user', userRoutes);

// Mount shop routes
app.use('/api/shop', shopRoutes);

// Mount product routes
app.use('/api/product', productRoutes);

// Mount order routes
app.use('/api/order', orderRoutes); // <-- This line was missing

app.listen(3000, () => console.log('Server running on port 3000'));

